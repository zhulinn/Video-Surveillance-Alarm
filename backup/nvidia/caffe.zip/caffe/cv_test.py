# -*- coding: utf-8 -*-
"""
Created on Wed Jul  6 17:32:01 2016

@author: root
"""

import cv2
import matplotlib.pyplot as plt
import time
import multiprocessing

def saveimage(filename,im):
    cv2.imwrite(filename, im)
    
cap = cv2.VideoCapture(0)
i = 0
time.clock()
record = []
cv2.namedWindow("Image")   
'''    
while 1:
#for i in range(20):
    _,im = cap.read()
    cv2.namedWindow("Image")   
    cv2.imshow("Image", im)   
    key = cv2.waitKey(1) & 0xFF
    if key == ord("s"):
        saveimage('screenshot.jpg', im)
    elif key == ord("q"):
		break
'''
for i in range(100):
#for i in range(20):
    _,im = cap.read()    
    cv2.imshow("Image", im)   
    key = cv2.waitKey(1) & 0xFF
#    if key == ord("s"):
    saveimage('screenshot{}.jpg'.format(i), im)
#    elif key == ord("q"):
#		break
print(time.clock())
cap.release()
cv2.destroyWindow('Image')    
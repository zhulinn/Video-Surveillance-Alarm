# -*- coding: utf-8 -*-
"""
Created on Wed Jul  6 19:05:22 2016

@author: root
"""


import cv2
import matplotlib.pyplot as plt
import time
import multiprocessing

def saveimage(filename,im):
    cv2.imwrite(filename, im)
    
cap = cv2.VideoCapture(0)
i = 0
time.clock()
record = []

while 1:
#for i in range(20):
    _,im = cap.read()
    cv2.namedWindow("Image")   
    cv2.imshow("Image", im)   
    key = cv2.waitKey(1) & 0xFF
    if key == ord("s"):
        saveimage('screenshot_{}.jpg'.format(i), im)
        i=i+1
        #time.sleep(0.05)
    elif key == ord("q"):
		break


#		break
print(time.clock())
cap.release()
cv2.destroyWindow('Image')    